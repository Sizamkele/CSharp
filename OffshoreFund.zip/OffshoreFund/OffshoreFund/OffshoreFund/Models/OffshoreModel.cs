﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OffshoreFund.Models
{
    public class OffshoreModel
    {

            
            [DisplayName("Name")]
            [RegularExpression(@"^[a-zA-Z]+", ErrorMessage = "Use letters only please")]
            [Required(ErrorMessage = "Name is required")]
            [DataType(DataType.Text)]
            public string Name { get; set; }

            [DisplayName("Funds")]
            [DataType(DataType.MultilineText)]
            public string OffshoreFund  { get; set; }

            [DisplayName("Amount")]
            [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0")]
            [Required(ErrorMessage = "Amount is required")]
            [DataType(DataType.Currency)]
            public decimal Amount { get; set; }

            [DisplayName("Debit Date")]
            [Required(ErrorMessage = "Date is required")]
            [DataType(DataType.Date)]
            public DateTime DateCalculation { get; set; }

            public decimal TotalAmount { get; set; }
           
           
        
    }
}