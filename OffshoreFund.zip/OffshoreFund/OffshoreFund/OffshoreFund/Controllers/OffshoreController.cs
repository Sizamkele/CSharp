﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

using System.Web.Script.Serialization;
using OffshoreFund.Models;
using System.Text.RegularExpressions;
using System.IO;

namespace OffshoreFund.Controllers
{
    public class OffshoreController : Controller
    {
        decimal priceRate = 0;


        // Get values
        public ActionResult GetInputValues()
        {
           
            OffshoreModel viewModel = new OffshoreModel();
            return View(viewModel);
        }

        // Get values , convert the rate and add results to a file 
        public ActionResult ConvertCurrencyResult(OffshoreModel model)
        
        {
             string rateTo = "ZAR";  
             decimal reteResults=  GetExchangeRate(model.OffshoreFund, rateTo);
             decimal TotalRate = model.Amount * priceRate;
             model.TotalAmount = TotalRate;

             // Set a variable to the My Documents path.
             string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            
             // Append text to an existing file named "WriteLines.txt".
             using (StreamWriter outputFile = new StreamWriter(mydocpath + @"\WriteLines.txt", true))
             {
                
                 outputFile.WriteLine("Name" + "             "+ model.Name ); 
                 outputFile.WriteLine("Fund" + "             "+ model.OffshoreFund ); 
                 outputFile.WriteLine("ZarAmount" + "        "+ model.Amount );
                 outputFile.WriteLine("ConvertedAmount" +    "   "+ TotalRate ); 
                 outputFile.WriteLine("Debit Date" + "       "+ model.DateCalculation ); 
                  outputFile.WriteLine("Submit Date" + "      "+ DateTime.Now); 
                  outputFile.WriteLine("Exchange Rate" + "    "+ priceRate ); 
               
                 outputFile.Flush();
                 outputFile.Close();
                 outputFile.Dispose();

             }
             
           
            return View(model);
        }

        //Get exchache rate from cloud.psg-online.co.za 
        public decimal GetExchangeRate(string fromRate, string toRate)
    
        {

            string url = string.Format("http://cloud.psg-online.co.za/RestTest/GetExchangeRate", fromRate, toRate);

            WebClient client = new WebClient();

            string clientResults = client.DownloadString(url);

         
            var serializer = new JavaScriptSerializer();
            dynamic result = serializer.DeserializeObject(clientResults);
         
            foreach (var item in result)
            {
                var name = item["Name"];
                decimal price = item["Price"];
                string output = name.Substring(name.IndexOf('/') + 1);
                if (output == fromRate)
                {
                    priceRate = price;

                }

            }
            
           return 0 ;

        }
      

    }
}
